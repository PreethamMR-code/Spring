package com.xworkz.model.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

@Component
public class OTPUtil {

    @Autowired
    JavaMailSender javaMailSender;

     public void sendOtpMail(String otp) {

        SimpleMailMessage message = new SimpleMailMessage();
        //otp is sent from this email
        message.setFrom("preethampreetham560@gmail.com");

        // email to receive otp
        message.setTo("whoareyouhaa123@gmail.com");

        message.setSubject("Login OTP");
        message.setText("Your OTP is: " + otp);

        javaMailSender.send(message);
    }
}
