package com.xworkz.model.controller;

import com.xworkz.model.DTO.StudentDTO;
import com.xworkz.model.entity.StudentEntity;
import com.xworkz.model.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Controller
public class XworkzController {

    @Autowired
    private StudentService studentService;

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @GetMapping("/signup")
    public String signupPage(Model model) {
        model.addAttribute("studentDTO", new StudentDTO());
        return "signup";
    }

    @PostMapping("/signup")
    public String signup(
            @Valid @ModelAttribute("studentDTO") StudentDTO dto,
            BindingResult bindingResult,
            Model model) {

        // Bean validation errors
        if (bindingResult.hasErrors()) {

//            System.out.println(bindingResult.toString());
//            if (bindingResult.hasFieldErrors("name")) {
//                model.addObject("nameError", bindingResult.getFieldError("name").getDefaultMessage());
//            }
//
//            if (bindingResult.hasFieldErrors("email")) {
//                model.addObject("emailError", bindingResult.getFieldError("email").getDefaultMessage());
//            }
//
//            if (bindingResult.hasFieldErrors("phone")) {
//                model.addObject("phoneError", bindingResult.getFieldError("phone").getDefaultMessage());
//            }
//
//            if (bindingResult.hasFieldErrors("age")) {
//                model.addObject("ageError", bindingResult.getFieldError("age").getDefaultMessage());
//            }
//
//            if (bindingResult.hasFieldErrors("gender")) {
//                model.addObject("genderError", bindingResult.getFieldError("gender").getDefaultMessage());
//            }
//
//            if (bindingResult.hasFieldErrors("address")) {
//                model.addObject("addressError", bindingResult.getFieldError("address").getDefaultMessage());
//            }
//
//            if (bindingResult.hasFieldErrors("password")) {
//                model.addObject("passwordError", bindingResult.getFieldError("password").getDefaultMessage());
//            }
//
//            if (bindingResult.hasFieldErrors("confirmPassword")) {
//                model.addObject("confirmPasswordError",
//                        bindingResult.getFieldError("confirmPassword").getDefaultMessage());
//            }
//             if (!dto.getPassword().equals(dto.getConfirmPassword())) {
//                 model.addObject("confirmPasswordError", "Passwords do not match");
//             }


            bindingResult.getFieldErrors().forEach(error -> {
                model.addAttribute(
                        error.getField() + "Error",
                        error.getDefaultMessage()
                );
            });

            model.addAttribute("error", "Please fix the errors below");
            return "signup";
        }

        // Password match validation
        if (!dto.getPassword().equals(dto.getConfirmPassword())) {
            model.addAttribute("confirmPasswordError", "Passwords do not match");
            model.addAttribute("error", "Please fix the errors below");
            return "signup";
        }

        // Save student
        boolean saved = studentService.saveStudent(dto);

        if (saved) {
            model.addAttribute("msg", "Account created successfully");
            return "login";
        }

        // Email already exists
        model.addAttribute("error", "Email already exists");
        return "signup";
    }

    // ================= LOGIN =================

    @GetMapping("/login")
    public String showLogin(Model model) {

        // reset all UI flags & messages
        model.addAttribute("error", null);
        model.addAttribute("msg", null);
        model.addAttribute("disableLogin", false);
        model.addAttribute("showOtp", false);
        model.addAttribute("showForgot", false);
        model.addAttribute("userEmail", null);

        return "login";
    }


    @PostMapping("/login")
    public String signIn(String email, String password, Model model) {


        if (email == null || email.trim().isEmpty()) {
            model.addAttribute("error", "Please enter your email");
            return "login";
        }

        // check if email exists
        StudentEntity entity = studentService.findByEmail(email);

        if(entity == null){
            model.addAttribute("error", "Your email does not exist. Please create an account.");
            return "login";
        }


        //validate the password
        boolean valid = studentService.validateLogin(email, password);

        if (valid) {
            // reset failed attempts
            studentService.setCountToZero(email);

            model.addAttribute("msg", "Login successful");
            return "dashboard";
        }

        // email exists but wrong credentials
        int count = studentService.updateCount(email);
        model.addAttribute("userEmail", email);

        if (count >= 3) {
            model.addAttribute("disableLogin", true);
            model.addAttribute("showForgot", true);
            model.addAttribute("showOtp", true);
            model.addAttribute("error",
                    "3 times wrong password entered for " + email +
                            ". Account has been blocked.");
            return "login";
        }

        model.addAttribute("error","Invalid password (" +count + "/3");
        return "login";
    }


    @PostMapping("/send-otp")
    public String sendOtp(@RequestParam String email, Model model) {

        System.out.println("sendOtp() called for: " + email);

        boolean saved = studentService.generateAndSendOtp(email);

        System.out.println("OTP save result: " + saved);

        if(saved) {
            model.addAttribute("showOtp", true);
            model.addAttribute("userEmail", email);
            model.addAttribute("msg", "OTP sent to your email");
        }else {
            model.addAttribute("error","Unable to send OTP. Email not found.");
        }
        return "login";
    }

    @PostMapping("/verify-otp")
    public String verifyOtp(
            @RequestParam String email,
            @RequestParam String otp,
            Model model) {

        boolean valid = studentService.verifyOtp(email, otp);

        if (valid) {
            studentService.setCountToZero(email);
            model.addAttribute("msg", "OTP verified successfully");
            return "dashboard";
        }

        model.addAttribute("error", "Invalid OTP");
        model.addAttribute("showOtp", true);
        model.addAttribute("userEmail", email);
        return "login";
    }


}
